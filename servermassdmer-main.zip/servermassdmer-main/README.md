### MASSDMER SERVER VERISON:
uh so it massdm withwout perms

### Current Worked Benchmarks:
- Working: `1000%`
- NotWorking: `26%`


| SS OF THE TOOL| 
| ------------- | 
| ![image](https://cdn.discordapp.com/attachments/855834309030051860/862853719591092234/unknown.png) |
